The program arranges data of a given file in ascending order: name->marks->roll number
The prpgram is written in C Language.
To run the program, you need gcc compiler.:
commands- gcc string_tuple_sort.c->./a.out