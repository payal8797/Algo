#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct node node; //STructure is created
struct node
{
    char name[20];
    int rollno;
    int marks;
    node *next;
};

void print_list(node *start)   //his function prints the list arranges in ascending order
{
    node *temp;
    printf("\nName\t\tMarks\tRollno\n");
    for(temp=start;temp!=NULL;temp=temp->next)
    {
        printf("%s\t\t%d\t%d\n",temp->name,temp->rollno,temp->marks);
    }
}
int main()
{
    FILE *fp;
    char name[50],token,n[50];                      //declarations
    int roll_no, marks,result,m,r,flag=0;
    node *nw,*temp,*prev;
    node *start=NULL,*end=NULL;
    fp = fopen("input_file.txt", "r");              //input file that is to be sorted
 
    if(fp == NULL)
    {
        printf("File opening error\n");
        exit(1);
    }

    while( fscanf(fp,"%s\t%c%d\t%c%d\n",name,&token,&roll_no,&token,&marks) != EOF )
    {
        nw=malloc(sizeof(node));
        nw->next=NULL;
        strcpy(nw->name,name);
        nw->rollno=roll_no;
        nw->marks=marks;

        if (start==NULL)
        {
            start=end=nw;
        }
        else 
        {
            for(temp=start;temp!=NULL;prev=temp,temp=temp->next)
            {
                result=strcmp(temp->name,nw->name);
                if(result>0)
                {
                    strcpy(n,nw->name);
                    m=nw->marks;
                    r=nw->rollno;

                    strcpy(nw->name,temp->name);
                    nw->marks=temp->marks;
                    nw->rollno=temp->rollno;

                    strcpy(temp->name,n);
                    temp->marks=m;
                    temp->rollno=r;
                   
                }

            }
            if (temp==NULL && flag==0)
            { // end->next=nw;
            // end=end->next;

            //>0 2nd
            //<0 1st
            //= equal
                prev->next=nw;
            }
        }
    }
    print_list(start);
    fclose(fp);
    return 0;
}
